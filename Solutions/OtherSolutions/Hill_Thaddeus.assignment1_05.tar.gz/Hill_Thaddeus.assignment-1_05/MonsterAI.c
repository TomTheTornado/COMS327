#include <stdio.h>
#include <stdlib.h>
#include "Headers/MonsterAI.h"

void runAI(dungeon_t *d, turn_t *p){
    switch (p->character->ID){
        case('s'):
            SkeletonAI(d, p);
            break;
        case('c'):
            CultistAI(d, p);
            break;
        case('O'):
            BeholderAI(d, p);
            break;
        case('w'):
            WraithAI(d, p);
            break;
        case('D'):
            DrillerAI(d, p);
            break;
        case('p'):
            PlagaAI(d, p);
            break;
        case('z'):
            ZombieAI(d, p);
            break;
        case('6'):
            AI0111(d, p);
            break;
        case('5'):
            AI1000(d, p);
            break;
        case('d'):
            DaemonAI(d, p);
            break;
        case('L'):
            LamiaAI(d, p);
            break;
        case('N'):
            NightwingAI(d, p);
            break;
        case('M'):
            MinotaurAI(d, p);
            break;
        case('2'):
            AI1101(d, p);
            break;
        case('S'):
            BasiliskAI(d, p);
            break;
        case('B'):
            BerserkerAI(d, p);
            break;
    }
}

//0001 = Intelligent, 0010 = Telepathic, 0100 = Tunneling , 1000 = Erratic
//0000 - Done - Testing - Seems fine
void SkeletonAI(dungeon_t *d, turn_t *p){
    if(findTarget(d, p) == 1){ //Can sense the Player
        genPaths(d, p->character->target->pos); //Gen Path to Player
        moveTowardsTarget(d, p, d->nonTunnelingPaths); //Move according to NonTunneling Paths
    }else{//Cannot sense Player
        if(p->character->playerSeen){ //Forgets the player's last position and choses a new goal
            p->character->playerSeen = 0;
            wanderNewGoal(d, p);
        }else
            wander(d, p); //Wander to a position
    }
    return;
}
//0001 - Intelligent - Done - Testing - Seems fine
void CultistAI(dungeon_t *d, turn_t *p){
    if(findTarget(d, p) == 1){ //Can see the Player
        genPaths(d, p->character->target->pos); //Gen Path to the PLayer
        moveTowardsTarget(d, p, d->nonTunnelingPaths); //Move according to NonTunneling Paths
    }else{ //Cannot See the player
        wander(d, p); //Player's last location is still goal, will complete movement to goal then chose a new goal
    }
    return;
}
//0010 - Telepathic (Hunts the player at all times)
void BeholderAI(dungeon_t *d, turn_t *p){
    genPaths(d, p->character->target->pos);
    moveTowardsTarget(d, p, d->nonTunnelingPaths);
}
//0011 - Done - Tested
void WraithAI(dungeon_t *d, turn_t *p){
    if(p->character->playerSeen){
        p->character->target = d->characters[d->player.y][d->player.x];
        genPaths(d, p->character->target->pos);
        moveTowardsTarget(d, p, d->nonTunnelingPaths);
    }else{
        if(findTarget(d, p) == 1){
            genPaths(d, p->character->target->pos);
            moveTowardsTarget(d, p, d->nonTunnelingPaths);
        }else{
            wait();
        }
    }
    return;
}
//0100 - Done - Testing - 
void DrillerAI(dungeon_t *d, turn_t *p){
    if(findTarget(d, p) == 1){
        genPaths(d, p->character->target->pos);
        moveTowardsTarget(d, p, d->tunnelingPaths);
    }else{
        wanderT(d, p);
    }
    return;
}
//0101 - Done 
void PlagaAI(dungeon_t *d, turn_t *p){
    if(p->character->playerSeen && p->character->pos.y != p->character->goal.y && p->character->pos.x != p->character->goal.x){
        genPaths(d, p->character->goal);
        moveTowardsTarget(d, p , d->tunnelingPaths);
    }else{
        if(findTarget(d, p) == 1){
            genPaths(d, p->character->target->pos);
            moveTowardsTarget(d, p, d->tunnelingPaths);
        }else{
            wanderT(d, p);
        }
    }
    return;
}
//0110 - Done
void ZombieAI(dungeon_t *d, turn_t *p){
    if(findTarget(d, p) == 1){
        genPaths(d, p->character->target->pos);
        moveTowardsTarget(d, p, d->tunnelingPaths);
    }else{
        wait();
    }
    return;
}
//0111 - In Progress - TBD Tunnelling, Telepathic, Intelligent
void AI0111(dungeon_t *d, turn_t *p){
    if(findTarget(d, p) == 1){
        genPaths(d, p->character->target->pos);
        moveTowardsTarget(d, p, d->nonTunnelingPaths);
    }else{
        wanderT(d, p);
    }
    return;
}
//1000 - In Progress - TBD Erratic
void AI1000(dungeon_t *d, turn_t *p){
   if(findTarget(d, p) == 1){
        genPaths(d, p->character->target->pos);
        moveTowardsTarget(d, p, d->nonTunnelingPaths);
    }else{
        wait();
    }
    return;
}
//1001 - In Progress
void DaemonAI(dungeon_t *d, turn_t *p){
    if(findTarget(d, p) == 1){ //Can see the Player
        genPaths(d, p->character->target->pos); //Gen Path to the PLayer
        moveTowardsTargetE(d, p, d->nonTunnelingPaths); //Move according to NonTunneling Paths
    }else{ //Cannot See the player
        wanderE(d, p); //Player's last location is still goal, will complete movement to goal then chose a new goal
    }
    return;
}
//1010 Telepathic(Hunts the player), Erratic (can kill other monsters)
void NightwingAI(dungeon_t *d, turn_t *p){
    if(p->character->playerSeen){
        p->character->target = d->characters[d->player.y][d->player.x];
        genPaths(d, p->character->target->pos);
        moveTowardsTargetE(d, p , d->nonTunnelingPaths);
    }else{
        if(findTarget(d, p) == 1){
            genPaths(d, p->character->target->pos);
            moveTowardsTargetE(d, p, d->nonTunnelingPaths);
        }else{
            wanderE(d, p);
        }
    }
    return;
}
//1011 -Intelligent (Avoids B and S), Telepathic(Hunts the player), Erratic (can kill other monsters)
void LamiaAI(dungeon_t *d, turn_t *p){
    if(p->character->playerSeen){
        p->character->target = d->characters[d->player.y][d->player.x];
        genPaths(d, p->character->target->pos);
        moveTowardsTargetE(d, p , d->nonTunnelingPaths);
    }else{
        if(findTarget(d, p) == 1){
            genPaths(d, p->character->target->pos);
            moveTowardsTargetE(d, p, d->nonTunnelingPaths);
        }else{
            wanderE(d, p);
        }
    }
    return;
}
//1100 - Done - Testing
void MinotaurAI(dungeon_t *d, turn_t *p){
    if(findTarget(d, p) == 1){
        genPaths(d, p->character->target->pos);
        moveTowardsTargetE(d, p, d->tunnelingPaths);
    }else{
        wanderTE(d, p);
    }
    return;
}
//1101 - In Progress //Erratic, Tunnneling, Intelligent
void AI1101(dungeon_t *d, turn_t *p){
    if(findTarget(d, p) == 1){
        genPaths(d, p->character->target->pos);
        moveTowardsTarget(d, p, d->nonTunnelingPaths);
    }else{
        wanderTE(d, p);
    }
    return;
}
//1110 - In Progress
void BasiliskAI(dungeon_t *d, turn_t *p){
    if(findTarget(d, p) == 1){
        genPaths(d, p->character->target->pos);
        moveTowardsTargetE(d, p, d->tunnelingPaths);
    }else if(findTarget(d, p) == 2){
        genPaths(d, p->character->target->pos);
        moveTowardsTargetE(d, p, d->tunnelingPaths);
    }else{
        wanderTE(d, p);
        return;
    }
    return;
}
//1111 - Done - Revist
void BerserkerAI(dungeon_t *d, turn_t *p){
    if(p->character->playerSeen){
        p->character->target = d->characters[d->player.y][d->player.x];
        genPaths(d, p->character->target->pos);
        moveTowardsTargetE(d, p , d->nonTunnelingPaths);
    }else if(findTarget(d, p) == 1 || findTarget(d,p) == 2){
        genPaths(d, p->character->target->pos);
        moveTowardsTargetE(d, p, d->tunnelingPaths);
    }else{
        wait();
        return;
    }
    return;
}

void standInAI(dungeon_t *d, turn_t *p){
    //moveTowardsPlayer(d, p, d->nonTunnelingPaths);
    wander(d, p);
    return;
}

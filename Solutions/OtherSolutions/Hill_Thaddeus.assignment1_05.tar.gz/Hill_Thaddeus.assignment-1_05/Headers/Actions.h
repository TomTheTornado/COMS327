#ifndef Actions_H_
#define Actions_H_

#include <stdint.h>
#include "Generator.h"
#include "Dungeon.h"
#include "PathFinding.h"

typedef struct view{
    heap_node_t *hn;
    location_t pos;
    int32_t cost;
}view_t;

/**
 * Movement for characters that are not erratic, this forbids battling anything other than the player.
 * */
int moveCharacter(dungeon_t *d, turn_t *p, int8_t yM, int8_t xM); 
/**
 * Movement for characters that are erratic, allows battling anything
 * */
void moveCharacterE(dungeon_t *d, turn_t *p, int8_t yM, int8_t xM);
/**
 * */
void moveTowardsTarget(dungeon_t *d, turn_t *p, uint16_t paths[DUNGEON_HEIGHT][DUNGEON_WIDTH]);
/**
 * */
void moveTowardsTargetE(dungeon_t *d, turn_t *p, uint16_t paths[DUNGEON_HEIGHT][DUNGEON_WIDTH]);
/**
 * */
void wander(dungeon_t *d, turn_t *p);
/**
 * */
void wanderT(dungeon_t *d, turn_t *p);
/**
 * */
void wanderE(dungeon_t *d, turn_t *p);
/**
 * */
void wanderTE(dungeon_t *d, turn_t *p);
/**
 * */
void wanderNewGoal(dungeon_t *d, turn_t *p);
/**
 * */
int findTarget(dungeon_t *d, turn_t *p);
/**
 * */
int selectTarget(dungeon_t *d, turn_t *p, character_t **mIV, uint8_t numDetected);
/**
 * */
void wait();
/**
 * */
void battle(dungeon_t *d, character_t *attacker, character_t *defender);
/**
 * */
void kill(dungeon_t *d, character_t *monster);
/**
 * */
void displayMonsterList(dungeon_t *d);

#endif
#ifndef Dungeon_H_
#define Dungeon_H_

#include <stdint.h>
#include "heap.h"

//Dungeon Specs
#define DUNGEON_WIDTH       80
#define DUNGEON_HEIGHT      21
#define MIN_ROOMS           6
#define MAX_ROOMS           10
#define MIN_ROOM_WIDTH      4
#define MAX_ROOM_WIDTH      12
#define MIN_ROOM_HEIGHT     3
#define MAX_ROOM_HEIGHT     9
#define MAX_ROOM_ATTEMPTS   2000
#define MAX_MONSTERS        10

#define mapxy(x, y) (d->map[y][x])
#define hardnessxy(x, y) (d->hardness[y][x])
#define weight(x, y) (d->hardness[y][x] / 85 + 1)


//Dungeon Geography Variables
typedef enum geography{
    g_rock,
    g_wall,
    g_room,
    g_corridor,
    g_up_stairs,
    g_down_stairs,
    g_stairs,
    g_trap
}geo_t;

typedef struct location{
    int8_t y;
    int8_t x;
}location_t;

typedef struct room{
    location_t location;
    uint8_t width;
    uint8_t height;
    uint8_t PCSpawn;
}room_t;

typedef struct character{
    char ID; //What the character will be represented by and determines the type of character
    uint8_t speed; //Speed of the character - Determined by Monster type 
    uint8_t traits; //0 - 15 determining which monster the character is
    location_t pos; //Location of the character
    uint8_t numMonster; //Which Monster the character is - Empty for Player
    uint8_t attack; //Attack of the character - Determined by Monster type 
    uint8_t defense; //Defense of the character - Determined by Monster type 
    uint8_t HP; //HP of the character - Determined by Monster type 
    uint8_t room; //Current Room the character is in
    struct character* target; //Target Monster
    location_t goal;
    uint8_t playerSeen;
}character_t;

typedef struct turn{
    heap_node_t *hn;
    character_t *character;
    uint32_t turn;
} turn_t;

typedef struct dungeon{
    //Seed, Environment map, Hardness map, Weight, and Visual map.
    uint32_t seed;
    geo_t map[DUNGEON_HEIGHT][DUNGEON_WIDTH];
    uint8_t hardness[DUNGEON_HEIGHT][DUNGEON_WIDTH];
    //uint8_t weight[DUNGEON_HEIGHT][DUNGEON_WIDTH];

    //Room info
    uint8_t num_rooms;
    room_t *rooms;

    //Stair info
    location_t *upstairs;
    location_t *downstairs;
    uint8_t num_upstairs;
    uint8_t num_downstairs;

    //Player
    location_t player;
    int8_t player_HP;

    //Characters
    uint16_t num_monsters;
    uint16_t max_monsters;
    character_t *characters[DUNGEON_HEIGHT][DUNGEON_WIDTH];
    character_t *monsterList;

    //Pathfinding
    uint16_t nonTunnelingPaths[DUNGEON_HEIGHT][DUNGEON_WIDTH];
    uint16_t tunnelingPaths[DUNGEON_HEIGHT][DUNGEON_WIDTH];
    //uint8_t visitedPF[DUNGEON_HEIGHT][DUNGEON_WIDTH];
}dungeon_t;

#endif //Dungeon_H_
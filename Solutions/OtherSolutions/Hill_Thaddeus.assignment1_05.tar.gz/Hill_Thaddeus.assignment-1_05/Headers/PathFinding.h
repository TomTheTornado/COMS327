#ifndef PathFinding_h
#define PathFinding_h

#include "heap.h"
#include "Dungeon.h"

typedef struct path_finding{
    heap_node_t *hn;
    location_t pos;
    location_t from;
    int32_t cost;
} pathFinding_t;

void iniArrays(dungeon_t *d);

int32_t pathFinding_cmp(const void *key, const void *with);

void dijkstraPF(dungeon_t *d, location_t pos, uint8_t mode);

/**
 * Gets the distance map for both tunneling and non tunneling arrays
 * */
void genPaths(dungeon_t *d, location_t pos);

#endif
#ifndef Player_H_
#define Player_H_

#include "Actions.h"

int playerMove(dungeon_t *d, turn_t *p);

#endif
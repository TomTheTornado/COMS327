#ifndef Load_Save_H_
#define Load_Save_H_

#include "Generator.h"

#define MARK        "RLG327-S2019"

typedef enum open
{
    readIt,
    writeIt
}open_t;

/**
 * Loads a dungeon from a file
 * */
int loadDungeon(dungeon_t *d);

/**
 * Saves a dungeon to a file
 * */
int saveDungeon(dungeon_t *d);

/**
 * Opens a file for reading or writing
 * */
int openFile(FILE **f, open_t open);

#endif //Load_Save_H_
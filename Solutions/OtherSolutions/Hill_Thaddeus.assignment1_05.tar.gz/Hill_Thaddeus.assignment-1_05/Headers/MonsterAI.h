#ifndef MonsterAI_H_
#define MonsterAI_H_

#include "Actions.h"

void runAI(dungeon_t *d, turn_t *p);

void SkeletonAI(dungeon_t *d, turn_t *p);

void CultistAI(dungeon_t *d, turn_t *p);

void BeholderAI(dungeon_t *d, turn_t *p);

void WraithAI(dungeon_t *d, turn_t *p);

void DrillerAI(dungeon_t *d, turn_t *p);

void PlagaAI(dungeon_t *d, turn_t *p);

void ZombieAI(dungeon_t *d, turn_t *p);

void AI0111(dungeon_t *d, turn_t *p);

void AI1000(dungeon_t *d, turn_t *p);

void DaemonAI(dungeon_t *d, turn_t *p);

void LamiaAI(dungeon_t *d, turn_t *p);

void NightwingAI(dungeon_t *d, turn_t *p);

void MinotaurAI(dungeon_t *d, turn_t *p);

void AI1101(dungeon_t *d, turn_t *p);

void BasiliskAI(dungeon_t *d, turn_t *p);

/**
 * Highly aggressive, Berserkers will hunt down and kill any monsters within its senses. 
 * If a Berserker detects the player, it will drop whatever it is doing and hunt the Player.
 * 
 * Berserkers are the most dangerous AI in the dungeon, having high Speed and Health, 
 *      but because they are so aggressive, they don't care to defend themselves much. As such, they have a low Defense.
 * 
 * Berserkers are Intelligent, and they know that they are the most dangerous monster around, fighting anything except other Berserkers.
 * */
void BerserkerAI(dungeon_t *d, turn_t *p);

void standInAI(dungeon_t *d, turn_t *p);

#endif
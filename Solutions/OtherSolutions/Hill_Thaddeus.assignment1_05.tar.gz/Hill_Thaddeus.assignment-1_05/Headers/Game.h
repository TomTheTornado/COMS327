#ifndef Game_H_
#define Game_H_

#include "LoadSave.h"
#include "MonsterAI.h"
#include "Player.h"

typedef enum action{
    base,
    load,
    save,
    load_save,
    testing
}action_t;

/**
 * Compares the turn values
 * */
int comTurn(const void *key, const void *with);

/**
 * Main game Loop, runs until the player reaches 0 HP
 * */
int gameLoop(dungeon_t *d);

//void updateCharacter(dungeon_t *d, turn_t *p);

#endif //Game_H_
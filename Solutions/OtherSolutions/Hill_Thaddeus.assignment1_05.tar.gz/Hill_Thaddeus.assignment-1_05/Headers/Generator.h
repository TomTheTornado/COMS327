#ifndef Generator_H_
#define Generator_H_

#include "Dungeon.h"
#include <stdint.h>
//#include <ncurses.h>

/**
 * Runs all the funcions to generate a dungeon
 * */
void generate(dungeon_t *d);

/**
 * Runs all the funcions to generate a new floor for the dungeon
 * */
void generateNextFloor(dungeon_t *d);

/**
 * Initializes the dungeon with rock
 * */
void cleanMap(dungeon_t *d);

/**
 * Sets all characters to Null to be filled again
 * */
void cleanCharacters(dungeon_t *d);

/**
 * Smooths the random hardness to a smoother gradient - makes the monsters move through rock in a more consistent way
 * */
int smoothHardness(int matrixSize, int matrix[matrixSize][matrixSize], uint8_t y, uint8_t x, uint8_t map[DUNGEON_HEIGHT][DUNGEON_WIDTH]);

/**
 * Generates the locations of the room's and places them with placeRoom()
 * */
void genRooms(dungeon_t *d);

/**
 * Places the room in the map
 * */
int placeRoom(dungeon_t *d);

/**
 * Generates the cooridors between rooms and places them with placeCorridor()
 * */
void genCorridors(dungeon_t *d);

/**
 * Places the cooridor in the map
 * */
void placeCorridor(dungeon_t *d, uint8_t y, uint8_t x);

/**
 * Generates the location of stairs in the dungeon and places them.
 * */
void genStairs(dungeon_t *d);

/**
 * Spawns the PC and initializes their character for the first time in the dungeon
 * */
void spawnPC(dungeon_t *d);

/**
 * Places the PC on a new floor retaining the stats from previous floor
 * */
void placePC(dungeon_t *d, int HP);

/**
 * Initializes the weight of movement map that monsters use to locate the player based on hardness and the player's location
 * */
void iniWeight(dungeon_t *d);

/**
 * Spawns random monsters in the dungeon -The player's spawn room is off-limits for spawning monsters
 * */
void spawnMonsters(dungeon_t *d);

/**
 * Identifies the Monster based on its traits and sets its ID accordingly
 * */
void IDMonster(dungeon_t *d, character_t *monster);

/**
 * Frees the dungeon to prevent memory leak
 * */
void freeDungeon(dungeon_t *d);

/**
 * Displays the dungeon to terminal
 * */
void display(dungeon_t *d);

/**
 * Displays the dungeon to the Window
 * */
void displayToWin(dungeon_t *d);

//Debug Funcions

/**
 * Displays the Weight, tunnelling, and nontunnelling, maps to the terminal for bug fixing
 * */
void displayPathsToWin(dungeon_t *d);

#endif //Generator_H_
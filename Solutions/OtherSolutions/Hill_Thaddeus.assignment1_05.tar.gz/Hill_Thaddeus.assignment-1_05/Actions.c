#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <limits.h>
#include <math.h>
#include <curses.h>
#include <ncurses.h>
#include "Headers/Actions.h"

int moveCharacter(dungeon_t *d, turn_t *p, int8_t yM, int8_t xM){
    if(yM != 0)
        yM = yM / abs(yM);
    if(xM != 0)
        xM = xM / abs(xM);
    int8_t cur_y, cur_x, y_goal, x_goal;
    cur_y = p->character->pos.y;
    cur_x = p->character->pos.x;
    y_goal = p->character->pos.y + yM;
    x_goal = p->character->pos.x + xM;

    if(cur_y == y_goal && cur_x == x_goal)
        return 1;
    else if(d->map[y_goal][x_goal] == g_wall)
        return 1;
    else if(d->map[y_goal][x_goal] == g_rock){
        if(d->hardness[y_goal][x_goal] - 85 <= 0){
            d->hardness[y_goal][x_goal] = 0;
            d->map[y_goal][x_goal] = g_corridor;
            //Move the Character
            d->characters[y_goal][x_goal] = d->characters[cur_y][cur_x];
            d->characters[cur_y][cur_x] = NULL;
            p->character->pos.y = y_goal;
            p->character->pos.x = x_goal;
            if(p->character->ID == *"@"){
                d->player.y = p->character->pos.y;
                d->player.x = p->character->pos.x;
            }else{
                d->characters[p->character->pos.y][p->character->pos.x]->pos.y = p->character->pos.y;
                d->characters[p->character->pos.y][p->character->pos.x]->pos.x = p->character->pos.x;
            }
        }else{
            d->hardness[y_goal][x_goal] = d->hardness[y_goal][x_goal] - 85;
        }
    }else{
        if(d->characters[y_goal][x_goal] == NULL){
            d->characters[y_goal][x_goal] = d->characters[cur_y][cur_x];
            d->characters[cur_y][cur_x] = NULL;
            p->character->pos.y = y_goal;
            p->character->pos.x = x_goal;
            if (p->character->ID == *"@"){
                d->player.y = p->character->pos.y;
                d->player.x = p->character->pos.x;
            }else{
                d->characters[p->character->pos.y][p->character->pos.x]->pos.y = p->character->pos.y;
                d->characters[p->character->pos.y][p->character->pos.x]->pos.x = p->character->pos.x;
            }
            //return 1;
        }else if(d->characters[y_goal][x_goal]->ID == *"@"){
            battle(d, d->characters[cur_y][cur_x], d->characters[y_goal][x_goal]);
            //return 1;
        }else{
            return 0;
        }
    }
    return 1;
}

void moveCharacterE(dungeon_t *d, turn_t *p, int8_t yM, int8_t xM){
    if(yM != 0)
        yM = yM / abs(yM);
    if(xM != 0)
        xM = xM / abs(xM);
    int8_t cur_y, cur_x, y_goal, x_goal;
    cur_y = p->character->pos.y;
    cur_x = p->character->pos.x;
    y_goal = p->character->pos.y + yM;
    x_goal = p->character->pos.x + xM;

    if(cur_y == y_goal && cur_x == x_goal)
        return;
    else if(d->map[y_goal][x_goal] == g_wall)
        return;
    else if(d->map[y_goal][x_goal] == g_rock){
        if(d->hardness[y_goal][x_goal] - 85 <= 0){
            d->hardness[y_goal][x_goal] = 0;
            d->map[y_goal][x_goal] = g_corridor;
            //Move the Character
            d->characters[y_goal][x_goal] = d->characters[cur_y][cur_x];
            d->characters[cur_y][cur_x] = NULL;
            p->character->pos.y = y_goal;
            p->character->pos.x = x_goal;
            if(p->character->ID == *"@"){
                d->player.y = p->character->pos.y;
                d->player.x = p->character->pos.x;
            }else{
                d->characters[p->character->pos.y][p->character->pos.x]->pos.y = p->character->pos.y;
                d->characters[p->character->pos.y][p->character->pos.x]->pos.x = p->character->pos.x;
            }
        }else{
            d->hardness[y_goal][x_goal] = d->hardness[y_goal][x_goal] - 85;
        }
    }else{
        if(d->characters[y_goal][x_goal] != NULL){
            battle(d, d->characters[cur_y][cur_x], d->characters[y_goal][x_goal]);
            return;
        }else{
            d->characters[y_goal][x_goal] = d->characters[cur_y][cur_x];
            d->characters[cur_y][cur_x] = NULL;
            p->character->pos.y = y_goal;
            p->character->pos.x = x_goal;
            if (p->character->ID == *"@"){
                d->player.y = p->character->pos.y;
                d->player.x = p->character->pos.x;
            }else{
                d->characters[p->character->pos.y][p->character->pos.x]->pos.y = p->character->pos.y;
                d->characters[p->character->pos.y][p->character->pos.x]->pos.x = p->character->pos.x;
            }
        }
    }
}
//Movement Funcions
void moveTowardsTarget(dungeon_t *d, turn_t *p, uint16_t paths[DUNGEON_HEIGHT][DUNGEON_WIDTH]){
    int8_t y, x, i, j;
    uint16_t lowest;
    lowest = 999;
    y = p->character->pos.y;
    x = p->character->pos.x;

    for (i = y - 1; i < y + 2; i++){
        for (j = x - 1; j < x + 2; j++){
            if(paths[i][j] < lowest)
                lowest = paths[i][j];
        }   
    }
    for (i = y - 1; i < y + 2; i++){
        for (j = x - 1; j < x + 2; j++){
            if(paths[i][j] == lowest){
                if(moveCharacter(d, p, i - y, j - x))
                    return;
                else
                    continue;
            }
            else
                continue;
        }   
    }

}

void moveTowardsTargetE(dungeon_t *d, turn_t *p, uint16_t paths[DUNGEON_HEIGHT][DUNGEON_WIDTH]){
    int8_t y, x, i, j;
    uint16_t lowest;
    lowest = 999;
    y = p->character->pos.y;
    x = p->character->pos.x;

    for (i = y - 1; i < y + 2; i++){
        for (j = x - 1; j < x + 2; j++){
            if(paths[i][j] < lowest)
                lowest = paths[i][j];
        }   
    }
    for (i = y - 1; i < y + 2; i++){
        for (j = x - 1; j < x + 2; j++){
            if(paths[i][j] == lowest)
                moveCharacterE(d, p, i - y, j - x);
        }   
    }

}
//Wander funcions
void wander(dungeon_t *d, turn_t *p){
    int8_t y, x;
    if (p->character->goal.y == p->character->pos.y && p->character->goal.x == p->character->pos.x){
        while (1){
            y = rand() % DUNGEON_HEIGHT;
            x = rand() % DUNGEON_WIDTH;
            if (d->hardness[y][x] == 0){
                location_t goal;
                goal.y = y;
                goal.x = x;
                p->character->goal = goal;
                break;
            }
            else
                continue;
        }
        genPaths(d, p->character->goal);
        moveTowardsTarget(d, p, d->nonTunnelingPaths);
        return;
    }
    genPaths(d, p->character->goal);
    moveTowardsTarget(d, p, d->nonTunnelingPaths);
    return;
}

void wanderT(dungeon_t *d, turn_t *p){
    int8_t y, x;
    if(p->character->goal.y != p->character->pos.y && p->character->goal.x != p->character->pos.x){
        genPaths(d, p->character->goal);
        moveTowardsTarget(d, p, d->tunnelingPaths);
        return;
    }
    while(1){
        y = rand() % DUNGEON_HEIGHT;
        x = rand() % DUNGEON_WIDTH;
        if(d->hardness[y][x] == 0){
            location_t goal;
            goal.y = y;
            goal.x = x;
            d->characters[p->character->pos.y][p->character->pos.x]->goal = goal;
            break;
        }
        else
            continue;
    }
    genPaths(d, p->character->goal);
    moveTowardsTarget(d, p, d->tunnelingPaths);
    return;
}

void wanderE(dungeon_t *d, turn_t *p){
    int8_t y, x;
    if(p->character->goal.y != p->character->pos.y && p->character->goal.x != p->character->pos.x){
        genPaths(d, p->character->goal);
        moveTowardsTargetE(d, p, d->nonTunnelingPaths);
        return;
    }
    while(1){
        y = rand() % DUNGEON_HEIGHT;
        x = rand() % DUNGEON_WIDTH;
        if(d->hardness[y][x] == 0){
            location_t goal;
            goal.y = y;
            goal.x = x;
            d->characters[p->character->pos.y][p->character->pos.x]->goal = goal;
            break;
        }
        else
            continue;
    }
    genPaths(d, d->characters[p->character->pos.y][p->character->pos.x]->goal);
    moveTowardsTargetE(d, p, d->nonTunnelingPaths);
    return;
}

void wanderTE(dungeon_t *d, turn_t *p){
    int8_t y, x;
    if(p->character->goal.y != p->character->pos.y && p->character->goal.x != p->character->pos.x){
        genPaths(d, p->character->goal);
        moveTowardsTargetE(d, p, d->tunnelingPaths);
        return;
    }
    while(1){
        y = rand() % DUNGEON_HEIGHT;
        x = rand() % DUNGEON_WIDTH;
        if(d->hardness[y][x] == 0){
            location_t goal;
            goal.y = y;
            goal.x = x;
            d->characters[p->character->pos.y][p->character->pos.x]->goal = goal;
            break;
        }
        else
            continue;
    }
    genPaths(d, p->character->goal);
    moveTowardsTargetE(d, p, d->tunnelingPaths);
    return;
}

void wanderNewGoal(dungeon_t *d, turn_t *p){
    uint8_t y, x;
    while (1)
    {
        y = rand() % DUNGEON_HEIGHT;
        x = rand() % DUNGEON_WIDTH;
        if (d->hardness[y][x] == 0)
        {
            location_t goal;
            goal.y = y;
            goal.x = x;
            d->characters[p->character->pos.y][p->character->pos.x]->goal = goal;
            break;
        }
        else
            continue;
    }
    genPaths(d, d->characters[p->character->pos.y][p->character->pos.x]->goal);
    moveTowardsTarget(d, p, d->nonTunnelingPaths);
    return;
}

int32_t inView_cmp(const void *key, const void *with){
    return ((view_t *)key)->cost - ((view_t *)with)->cost;
}

int findTarget(dungeon_t *d, turn_t *t){
    static view_t path[DUNGEON_HEIGHT][DUNGEON_WIDTH], *p;
    heap_t h;
    uint32_t y, x, i, j;
    uint8_t rangeR = 5, rangeL = 5, rangeU = 5, rangeD = 5;
    //Maximize range of senses for given area
    while(1){
        if(t->character->pos.y - rangeU < 0){
            rangeU--;
            continue;
        }else if(t->character->pos.y + rangeD > DUNGEON_HEIGHT){
            rangeD--;
            continue;
        }else if(t->character->pos.x - rangeL < 0){
            rangeL--;
            continue;
        }else if(t->character->pos.x + rangeR > DUNGEON_WIDTH){
            rangeR--;
            continue;
        }else
            break;
    }
    //Detect number of characters within range
    heap_init(&h, inView_cmp, NULL);
    //Prepare sense area with valid cells
    for (y = t->character->pos.y - rangeU; y < t->character->pos.y + rangeD; y++){
        for (x = t->character->pos.x - rangeL; x < t->character->pos.x + rangeR; x++){
            path[y][x].pos.y = y;
            path[y][x].pos.x = x;
            path[y][x].cost = (d->player.x != x || d->player.y != y) ? INT_MAX : 0; //Doesn't actually matter - could use a basic queue but priority queue is already implimented so why not

            if (d->hardness[y][x] == 0) //fill heap if a room or corridor
                path[y][x].hn = heap_insert(&h, &path[y][x]);
            else
                path[y][x].hn = NULL;
        }
    }
    //Detect number of monsters with range
    while ((p = heap_remove_min(&h))){
        p->hn = NULL;
        if(d->characters[p->pos.y][p->pos.x] != NULL && d->characters[p->pos.y][p->pos.x]->numMonster != t->character->numMonster)
            i++;
        else
            continue;
    }
    heap_delete(&h); //Delete heap for re-inialization
    if(i == 0){
        return 0; //No characters in range
    }
    character_t **charactersInView = malloc(sizeof(character_t) * i);
    heap_init(&h, inView_cmp, NULL);
    //Prepare heap for detecting characters specifically
    for (y = t->character->pos.y - rangeU; y < t->character->pos.y + rangeD; y++){
        for (x = t->character->pos.x - rangeL; x < t->character->pos.x + rangeR; x++){
            path[y][x].pos.y = y;
            path[y][x].pos.x = x;
            path[y][x].cost = (t->character->pos.x != x || t->character->pos.y != y) ? INT_MAX : 0;

            // if (mapxy(x, y) != g_wall || mapxy(x, y) != g_rock) //fill heap if not hard wall
            //     path[y][x].hn = heap_insert(&h, &path[y][x]);
            if (d->hardness[y][x] == 0) //fill heap if a room or corridor
                path[y][x].hn = heap_insert(&h, &path[y][x]);
            else
                path[y][x].hn = NULL;
        }
    }
    j = 0;
    //Add the detected characters to a list for analysis
    while ((p = heap_remove_min(&h))){
        p->hn = NULL;
        if(j == i) //Have we detected all the charaters to detect? Yes - break, No - continue on
            break;
        else if(d->characters[p->pos.y][p->pos.x] != NULL && d->characters[p->pos.y][p->pos.x]->numMonster != t->character->numMonster){ //If the space is not Null and isn't the monster doing the detecting
            charactersInView[j] = d->characters[p->pos.y][p->pos.x];//Add them to the list
            j++;
        }
        else
            continue;
    }
    heap_delete(&h);

    //Select target - may or may not be used depending on monster
    int m = selectTarget(d, t, charactersInView, i);
    free(charactersInView);
    return m; //Player is target: 1, PLayer not target: 2
}

int selectTarget(dungeon_t *d, turn_t *p, character_t **mIV, uint8_t numDetected){
    uint8_t i;
    character_t *target = mIV[0]; //Set target as the first monster in the list
    if(target->ID == '@'){ //Check if target is already the player
        p->character->playerSeen = 1;
        p->character->target = target; //Sets Player as character's target
        p->character->goal = target->pos; //Sets Player position as goal, will not retained if player is out of sight
        return 1; //PLayer found
    }else{
        for (i = 0; i < numDetected; i++){
            if(mIV[i] == NULL){
                break;
            }
            if (mIV[i]->ID == '@'){//Check if next character is Player
                target = mIV[i];
                p->character->playerSeen = 1;
                p->character->target = target; //Sets Player as character's target
                p->character->goal = target->pos; //Sets Player position as goal, will not retained if player is out of sight
                return 1; //Player found
            }
            else if ((abs(p->character->pos.y - mIV[i]->pos.y) < abs(p->character->pos.y - target->pos.y)) && (abs(p->character->pos.x - mIV[i]->pos.x) < abs(p->character->pos.x - target->pos.x))){ //Checks if next character is closer than current target
                target = mIV[i]; //Yes - set as new target, No - Continue
            }   
            else
                continue;
        }
        d->characters[p->character->pos.y][p->character->pos.x]->target = target;
        return 2; //Player not found in detected charaters
    }
}

void wait(){
    return;
}

void battle(dungeon_t *d, character_t *attacker, character_t *defender){
    uint8_t damage = attacker->attack - (attacker->attack * (defender->defense / 30));
    if(defender->ID == *"@"){
        if(defender->HP - damage <= 0){
            defender->HP = 0;
        }else{
            defender->HP = defender->HP - damage;
        }
        return;
    }else if(defender->HP - damage <= 0){
        kill(d, defender);
    }else{
        defender->HP = defender->HP - damage;
        return;
    }
    return;
}

void kill(dungeon_t *d, character_t *monster){
    d->characters[monster->pos.y][monster->pos.x] = NULL;
    free(d->characters[monster->pos.y][monster->pos.x]);
    d->num_monsters--;
    return;
}
//Player Only Actions
void displayMonsterList(dungeon_t *d){
    if(d->num_monsters == 0){
        move(0,0);
        clrtoeol();
        mvprintw(0, 0, "No Monsters detected. You're safe for now...");
        refresh();

        while(1){
            char ch = getch();
            switch(ch){
                case(27):
                    return;
                default:
                    continue;
            }
        }
    }else{
        d->monsterList = malloc(sizeof(character_t) * d->num_monsters);
        uint16_t y, x, i;
        i = 0;
        for (y = 0; y < DUNGEON_HEIGHT; y++)
        {
            for (x = 0; x < DUNGEON_WIDTH; x++)
            {
                if (d->characters[y][x] != NULL && d->characters[y][x]->ID != *"@")
                {
                    d->monsterList[i] = *d->characters[y][x];
                    i++;
                }
            }
        }
        int16_t line = 0;
        while (1){
            char *directionY = "Down";
            char *directionX = "Right";
            int8_t yD, xD;

            yD = d->monsterList[line].pos.y - d->player.y;
            xD = d->monsterList[line].pos.x - d->player.x;
            if (yD < 0)
                directionY = "Up";
            if (xD < 0)
                directionX = "Left";

            move(0, 0);
            clrtoeol();
            mvprintw(0, 0, "Monster: %c, %d %s and %d %s, Health: %d, Room: %d", d->monsterList[line].ID, abs(yD), directionY, abs(xD), directionX, d->monsterList[line].HP, d->monsterList[line].room);
            refresh();
            char ch = getch();
            switch (ch){
            case ((char)KEY_UP):
                if (line == 0)
                    line = d->num_monsters - 1;
                else
                    line--;
                continue;
            case ((char)KEY_DOWN):
                if (line == d->num_monsters - 1)
                    line = 0;
                else
                    line++;
                continue;
            case (27):
                return;
            default:
                continue;
            }
        }
        free(d->monsterList);
    }
}
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <endian.h>
#include "Headers/LoadSave.h"

int loadDungeon(dungeon_t *d){
    FILE *f = NULL;

    cleanMap(d);
    openFile(&f, readIt);
    char marker[13];
    uint32_t version_marker;
    uint32_t file_size;
    uint16_t i, j, k;

    fread(&marker, sizeof(char), 12, f);
    fread(&version_marker, sizeof(uint32_t), 1, f);
    marker[12] = '\0';
    if (strcmp(marker, MARK)) //check file marker
        return -1;

    if (be32toh(version_marker) != 0)
        return -1;

    fread(&file_size, sizeof(uint32_t), 1, f);
    fread(&d->player.x, sizeof(uint8_t), 1, f);
    fread(&d->player.y, sizeof(uint8_t), 1, f);

    fread(&d->hardness, sizeof(uint8_t), 1680, f);
    for(i = 0; i < DUNGEON_HEIGHT; i++){
        for(j = 0; j < DUNGEON_WIDTH; j++){
            //d->weight[i][j] = (d->hardness[i][j]/85) + 1;
        }
    }
    for(i = d->player.y-1; i < d->player.y + 2; i++){
        for(j = d->player.x-1; j < d->player.x + 2; j++){
            //d->weight[i][j] = 1;
        }
    }
    fread(&d->num_rooms, sizeof(uint16_t), 1, f);
    d->num_rooms = be16toh(d->num_rooms);
    d->rooms = malloc(sizeof(room_t) * d->num_rooms);

    //rooms
    for (i = 0; i < d->num_rooms; i++)
    {
        fread(&d->rooms[i].location.x, sizeof(uint8_t), 1, f);
        fread(&d->rooms[i].location.y, sizeof(uint8_t), 1, f);
        fread(&d->rooms[i].width, sizeof(uint8_t), 1, f);
        fread(&d->rooms[i].height, sizeof(uint8_t), 1, f);

        
        for (j = d->rooms[i].location.y; j < d->rooms[i].height + d->rooms[i].location.y; j++) //add to map
        {
            for (k = d->rooms[i].location.x; k < d->rooms[i].width + d->rooms[i].location.x; k++)
            {
                d->map[j][k] = g_room;
            }
        }
    }

    //upstairs
    fread(&d->num_upstairs, sizeof(uint16_t), 1, f);
    d->num_upstairs = be16toh(d->num_upstairs);
    d->upstairs = malloc(sizeof(location_t) * d->num_upstairs);
    for (i = 0; i < d->num_upstairs; i++)
    {
        fread(&d->upstairs[i].x, sizeof(uint8_t), 1, f);
        fread(&d->upstairs[i].y, sizeof(uint8_t), 1, f);
        d->map[d->upstairs[i].y][d->upstairs[i].x] = g_up_stairs;
    }

    // //downstairs
    fread(&d->num_downstairs, sizeof(uint16_t), 1, f);
    d->num_downstairs = be16toh(d->num_downstairs);
    d->downstairs = malloc(sizeof(location_t) * d->num_downstairs);
    for (i = 0; i < d->num_downstairs; i++)
    {
        fread(&d->downstairs[i].x, sizeof(uint8_t), 1, f);
        fread(&d->downstairs[i].y, sizeof(uint8_t), 1, f);
        d->map[d->downstairs[i].y][d->downstairs[i].x] = g_down_stairs;
    }

    for (i = 0; i < DUNGEON_HEIGHT; i++)
    {
        for (j = 0; j < DUNGEON_WIDTH; j++)
        {
            if (d->hardness[i][j] == 0 && d->map[i][j] == g_rock)
            {
                d->map[i][j] = g_corridor;
            }
        }
    }

    fclose(f);

    return 0;
}

int saveDungeon(dungeon_t *d){
    FILE *f = NULL;

    uint32_t mark_v = 0;
    mark_v = htobe32(mark_v);
    uint32_t file_size = 1708 + d->num_rooms * 4 + d->num_upstairs * 2 + d->num_downstairs * 2;
    file_size = htobe32(file_size);
    uint16_t num_rooms = d->num_rooms;
    num_rooms = htobe16(num_rooms);
    uint16_t num_upstairs = d->num_upstairs;
    num_upstairs = htobe16(num_upstairs);
    uint16_t num_downstairs = d->num_downstairs;
    num_downstairs = htobe16(num_downstairs);

    openFile(&f, writeIt); //open file

    fwrite(&MARK, 12, 1, f);                        //file marker
    fwrite(&mark_v, sizeof(uint32_t), 1, f);        //file version
    fwrite(&file_size, sizeof(uint32_t), 1, f);     //file size
    fwrite(&d->player.x, sizeof(uint8_t), 1, f);    //player x
    fwrite(&d->player.y, sizeof(uint8_t), 1, f);    //player y
    fwrite(&d->hardness, sizeof(uint8_t), 1680, f); //hardness array

    //rooms
    int i;
    fwrite(&num_rooms, sizeof(uint16_t), 1, f); //number of room
    for (i = 0; i < d->num_rooms; i++)
    {
        fwrite(&d->rooms[i].location.x, sizeof(uint8_t), 1, f);      //room x
        fwrite(&d->rooms[i].location.y, sizeof(uint8_t), 1, f);      //room y
        fwrite(&d->rooms[i].width, sizeof(uint8_t), 1, f);  //room width
        fwrite(&d->rooms[i].height, sizeof(uint8_t), 1, f); //room height
    }

    //upstairs
    fwrite(&num_upstairs, sizeof(uint16_t), 1, f); //number of up stairs
    for (i = 0; i < d->num_upstairs; i++)
    {
        fwrite(&d->upstairs[i].x, sizeof(uint8_t), 1, f); //upstair x
        fwrite(&d->upstairs[i].y, sizeof(uint8_t), 1, f); //upstair y
    }

    //downstairs
    fwrite(&num_downstairs, sizeof(uint16_t), 1, f); //num of down stairs
    for (i = 0; i < d->num_downstairs; i++)
    {
        fwrite(&d->downstairs[i].x, sizeof(uint8_t), 1, f); //downstair x
        fwrite(&d->downstairs[i].y, sizeof(uint8_t), 1, f); //downstair y
    }

    fclose(f); //close file
    printf("Finished Writing.\n");
    return 0;
}

int openFile(FILE **f, open_t open){
    char *path;

    char *home = getenv("HOME");

    if (!(path = malloc(strlen(home) + strlen("/.rlg327/dungeon") + 1)))
        return 1;

    strcpy(path, home);
    strcat(path, "/.rlg327/dungeon");

    switch (open)
    {
    case readIt:
        if (!(*f = fopen(path, "r")))
        {
            printf("Dungeon not found in default location. Falling back to working directory.\n");
            if (!(*f = fopen("dungeon", "r")))
            {
                printf("No dungeon found in working directory. Exiting\n");
                exit(-1);
            }
            return 1;
        }
        break;
    case writeIt:
        if (!(*f = fopen(path, "w")))
        {
            printf("Dungeon not found in default location. Falling back to working directory.\n");
            if (!(*f = fopen("dungeon", "w")))
            {
                printf("No dungeon found in working directory. Exiting\n");
                exit(-1);
            }
            return 1;
        }
        break;
    }

    free(path);
    return 0;
}
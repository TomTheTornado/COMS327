#include <stdio.h>
#include <stdint.h>
#include <time.h>
#include <stdlib.h>
#include <math.h>
#include <curses.h>
#include <ncurses.h>

#include "Headers/Generator.h"

void generate(dungeon_t *d){
    if(!d->seed){
        d->seed = time(NULL);
    }
    srand(d->seed);
    cleanMap(d);
    genRooms(d);
    genCorridors(d);
    genStairs(d);
    spawnPC(d);
    spawnMonsters(d);
}

void generateNextFloor(dungeon_t *d){
    uint8_t HP = d->characters[d->player.y][d->player.x]->HP;
    freeDungeon(d);
    cleanMap(d);
    genRooms(d);
    genCorridors(d);
    genStairs(d);
    placePC(d, HP);
    spawnMonsters(d);
}

void cleanMap(dungeon_t *d){
    uint8_t y, x;
    d->num_rooms = 0;
    for(y = 0; y < DUNGEON_HEIGHT; y++){
        for(x = 0; x < DUNGEON_WIDTH; x++){
            if(y == 0|| y == DUNGEON_HEIGHT - 1){
                d->map[y][x] = g_wall;
                d->hardness[y][x] = 255;
            }else if(x == 0 || x == DUNGEON_WIDTH - 1){
                d->map[y][x] = g_wall;
                d->hardness[y][x] = 255;
            }else{
                d->map[y][x] = g_rock;
                d->hardness[y][x] = (rand() % 253) + 1;
            }
        }
    }

    int matrix[3][3] = {
        {0, 2, 0},
        {2, 4, 2},
        {0, 2, 0}};

    uint8_t reference[DUNGEON_HEIGHT][DUNGEON_WIDTH];

    for(y = 1; y < DUNGEON_HEIGHT - 1; y++){
        for(x = 1; x < DUNGEON_WIDTH - 1; x++){
            reference[y][x] = d->hardness[y][x];
        }
    }

    for(y = 1; y < DUNGEON_HEIGHT - 1; y++){
        for(x = 1; x < DUNGEON_WIDTH - 1; x++){
            d->hardness[y][x] = smoothHardness(3, matrix, y, x, reference);
            if(d->hardness[y][x] > 254)
                d->hardness[y][x] = 254;
            if(d->hardness[y][x] < 1)
                d->hardness[y][x] = 1;
        }
    }
    return;
}

int smoothHardness(int matrixSize, int matrix[matrixSize][matrixSize], uint8_t y, uint8_t x, uint8_t map[DUNGEON_HEIGHT][DUNGEON_WIDTH]){
    int sum = 0;
    uint8_t i, j;
    for (i = 0; i < matrixSize; i++)
        for (j = 0; j < matrixSize; j++)
            sum += matrix[i][j] * map[y + (i - 1)][x + (j - 1)];

    return (sum / (matrixSize * matrixSize));
}

void genRooms(dungeon_t *d){
    uint16_t attempts = 0;
    d->rooms = malloc(sizeof(room_t) * MIN_ROOMS); //Changed MAX_ROOMS to MIN_ROOMS
    while(d->num_rooms < MIN_ROOMS){
        if(!placeRoom(d)){
            if(attempts >= MAX_ROOM_ATTEMPTS){
                break;
            }
            attempts++;
            continue;
        }
        attempts = 0;
        d->num_rooms++;
    }
    return;
}

int placeRoom(dungeon_t *d){
    room_t room;
    room.location.x = rand() % DUNGEON_WIDTH;
    room.location.y = rand() % DUNGEON_HEIGHT;
    room.width = (rand() % (MAX_ROOM_WIDTH - MIN_ROOM_WIDTH)) + MIN_ROOM_WIDTH;
    room.height = (rand() % (MAX_ROOM_HEIGHT - MIN_ROOM_HEIGHT)) + MIN_ROOM_HEIGHT;

    if(room.location.x < 2 || room.location.x > DUNGEON_WIDTH - (room.width + 2))
        return 0;
    else if(room.location.y < 2 || room.location.y > DUNGEON_HEIGHT - (room.height + 2))
        return 0;
    
    uint8_t y, x;
    for(y = room.location.y-1; y < room.height + room.location.y+1; y++){
        for(x = room.location.x-1; x < room.width + room.location.x+1; x++){
            if(d->map[y][x] != g_rock)
                return 0;
        }
    }
    for(y = room.location.y; y < room.height + room.location.y; y++){
        for(x = room.location.x; x < room.width + room.location.x; x++){
            d->map[y][x] = g_room;
            d->hardness[y][x] = 0;
        }
    }
    d->rooms[d->num_rooms] = room;
    return 1;
}

void genCorridors(dungeon_t *d){ //Change later
    int i;
    for (i = 0; i < d->num_rooms - 1; i++)
    {
        uint8_t cur_y, cur_x, tar_y, tar_x;

        //start location
        cur_y = d->rooms[i].location.y + (rand() % d->rooms[i].height);
        cur_x = d->rooms[i].location.x + (rand() % d->rooms[i].width);

        //target location
        tar_y = d->rooms[i + 1].location.y + (rand() % d->rooms[i + 1].height);
        tar_x = d->rooms[i + 1].location.x + (rand() % d->rooms[i + 1].width);

        while ((cur_x != tar_x) || (cur_y != tar_y)){
            int8_t horizontal_movement = (cur_x < tar_x) ? 1 : -1;
            int8_t vertical_movement = (cur_y < tar_y) ? 1 : -1;

            uint8_t pot_y = cur_y + vertical_movement;
            uint8_t pot_x = cur_x + horizontal_movement;

            float distance_x = sqrt(pow((tar_x - pot_x), 2) + pow(tar_y - cur_y, 2));
            float distance_y = sqrt(pow((tar_x - cur_x), 2) + pow(tar_y - pot_y, 2));
            float previous_d = sqrt(pow((tar_x - cur_x), 2) + pow(tar_y - cur_y, 2));

            if (distance_x < previous_d && distance_y < previous_d){
                if (d->hardness[cur_y][pot_x] < d->hardness[pot_y][cur_y])
                    cur_x += horizontal_movement;
                else
                    cur_y += vertical_movement;
            }else{
                if (distance_x < distance_y)
                    cur_x += horizontal_movement;
                else
                    cur_y += vertical_movement;
            }
            placeCorridor(d, cur_y, cur_x);
        }
    }
    return;
}

void placeCorridor(dungeon_t *d, uint8_t y, uint8_t x){
    if (d->map[y][x] == g_rock){
        d->map[y][x] = g_corridor;
        d->hardness[y][x] = 0;
    }
    return;
}

void genStairs(dungeon_t *d){
    uint8_t y, x;
    while (1){
        y = rand() % (DUNGEON_HEIGHT - 1) + 1;
        x = rand() % (DUNGEON_WIDTH - 1) + 1;

        if (d->hardness[y][x] == 0 && d->map[y][x] == g_room){
            d->num_downstairs = 1;
            d->downstairs = malloc(sizeof(location_t));
            d->downstairs[0].x = x;
            d->downstairs[0].y = y;
            d->map[y][x] = g_down_stairs;
            break;
        }
    }
    while (1){
        x = rand() % (DUNGEON_WIDTH - 1) + 1;
        y = rand() % (DUNGEON_HEIGHT - 1) + 1;

        if (d->hardness[y][x] == 0 && d->map[y][x] != g_down_stairs && d->map[y][x] == g_room){
            d->num_upstairs = 1;
            d->upstairs = malloc(sizeof(location_t));
            d->upstairs[0].x = x;
            d->upstairs[0].y = y;
            d->map[y][x] = g_up_stairs;
            break;
        }
    }
    return;
}

void spawnPC(dungeon_t *d){
    uint8_t y, x;
    uint8_t spawnRoom = rand() % d->num_rooms;
    d->rooms[spawnRoom].PCSpawn = 1;
    //Place in roughly center of spwanroom
    y = d->rooms[spawnRoom].location.y + (d->rooms[spawnRoom].height / 2);
    x = d->rooms[spawnRoom].location.x + (d->rooms[spawnRoom].width / 2);
    //Set up Character profile
    d->characters[y][x] = malloc(sizeof(character_t));
    d->characters[y][x]->ID = '@'; //Identifies the chracter as the player.
    d->characters[y][x]->speed = 10; //Speed always 10
    d->characters[y][x]->pos.y = y;
    d->characters[y][x]->pos.x = x;
    d->characters[y][x]->attack = 5; //Subject to change - need to balance combat
    d->characters[y][x]->defense = 10; //Subject to change - need to balance combat
    d->characters[y][x]->HP = 50; //Subject to change - need to balance combat
    d->characters[y][x]->room = spawnRoom;
    //Set location for easy access
    d->player.y = y;
    d->player.x = x;
}

void placePC(dungeon_t *d, int HP){
    uint8_t y, x;
    uint8_t spawnRoom = rand() % d->num_rooms;
    d->rooms[spawnRoom].PCSpawn = 1;

    y = d->rooms[spawnRoom].location.y + (d->rooms[spawnRoom].height / 2);
    x = d->rooms[spawnRoom].location.x + (d->rooms[spawnRoom].width / 2);

    d->characters[y][x] = malloc(sizeof(character_t));
    d->characters[y][x]->ID = '@';
    d->characters[y][x]->speed = 10;
    d->characters[y][x]->pos.y = y;
    d->characters[y][x]->pos.x = x;
    d->characters[y][x]->attack = 5;
    d->characters[y][x]->defense = 10;
    d->characters[y][x]->HP = HP;
    d->characters[y][x]->room = spawnRoom;
    //Set location for easy access
    d->player.y = y;
    d->player.x = x;


}

void spawnMonsters(dungeon_t *d){
    uint8_t y, x, attempts, max_attempts;
    max_attempts = 255;
    for(d->num_monsters = 0; d->num_monsters < d->max_monsters; d->num_monsters++){
    uint8_t spawnRoom = rand() % d->num_rooms;
    while(1){
        if(d->rooms[spawnRoom].PCSpawn == 1)
            spawnRoom = rand() % d->num_rooms;
        else
            break;
    }

    y = d->rooms[spawnRoom].location.y + rand() % d->rooms[spawnRoom].height;
    x = d->rooms[spawnRoom].location.x + rand() % d->rooms[spawnRoom].width;
    while(1){
        if(d->characters[y][x] != NULL){
            y = d->rooms[spawnRoom].location.y + rand() % d->rooms[spawnRoom].height;
            x = d->rooms[spawnRoom].location.x + rand() % d->rooms[spawnRoom].width;
            attempts++;
        }else{
            break;
        }
        if(attempts >= max_attempts){
            d->max_monsters--;
            attempts = 0;
        }
        if(d->num_monsters == d->max_monsters){
            return;
        }
    }

    d->characters[y][x] = malloc(sizeof(character_t));
    d->characters[y][x]->room = spawnRoom;
    d->characters[y][x]->traits = rand() % 16;
    //d->characters[y][x]->traits = 12;
    d->characters[y][x]->playerSeen = 0;
    d->characters[y][x]->pos.y = y;
    d->characters[y][x]->pos.x = x;
    d->characters[y][x]->goal.y = y;
    d->characters[y][x]->goal.x = x;
    d->characters[y][x]->numMonster = d->num_monsters;
    IDMonster(d, d->characters[y][x]);
    }
    return;
}

void IDMonster(dungeon_t *d, character_t *monster){
    switch(monster->traits){
        case(0):
            monster->ID = 's'; // 0000 //Skeleton
            monster->HP = 10;
            monster->speed = 7;
            monster->attack = 5;
            monster->defense = 5;
            break;
        case(1):
            monster->ID = 'c'; // 0001 - Cultist
            monster->HP = 15;
            monster->speed = 15;
            monster->attack = 5;
            monster->defense = 5;
            break;
        case(2):
            monster->ID = 'O'; // 0010 - Beholder
            monster->HP = 20;
            monster->speed = 8;
            monster->attack = 5;
            monster->defense = 5;
            monster->target = d->characters[d->player.y][d->player.x];
            monster->goal = d->characters[d->player.y][d->player.x]->pos;
            break;
        case(3):
            monster->ID = 'w'; // 0011 -Wraith
            monster->HP = 10;
            monster->speed = 12;
            monster->attack = 5;
            monster->defense = 2;
            break;
        case(4):
            monster->ID = 'D'; // 0100 -Driller
            monster->HP = 18;
            monster->speed = 12;
            monster->attack = 5;
            monster->defense = 5;
            break;
        case(5):
            monster->ID = 'p'; // 0101 -Plaga Zombie
            monster->HP = 12;
            monster->speed = 8;
            monster->attack = 5;
            monster->defense = 5;
            break;
        case(6):
            monster->ID = 'z'; // 0110 -Zombie
            monster->HP = 10;
            monster->speed = 8;
            monster->attack = 5;
            monster->defense = 5;
            break;
        case(7):
            monster->ID = '6'; // 0111 
            monster->HP = 20;
            monster->speed = 12;
            monster->attack = 5;
            monster->defense = 5;
            break;
        case(8):
            monster->ID = '5'; // 1000
            monster->HP = 10;
            monster->speed = 10;
            monster->attack = 5;
            monster->defense = 5;
            break;
        case(9):
            monster->ID = 'd'; // 1001 - Daemon
            monster->HP = 10;
            monster->speed = 10;
            monster->attack = 5;
            monster->defense = 5;
            break;
        case(10):
            monster->ID = 'N'; // 1010 //Nightwing
            monster->HP = 18;
            monster->speed = 20;
            monster->attack = 5;
            monster->defense = 5;
            break;
        case(11):
            monster->ID = 'L'; // 1011 //Lamia
            monster->HP = 15;
            monster->speed = 10;
            monster->attack = 5;
            monster->defense = 5;
            break;
        case(12):
            monster->ID = 'M'; // 1100 //Minotaur
            monster->HP = 10;
            monster->speed = 10;
            monster->attack = 5;
            monster->defense = 5;
            break;
        case(13):
            monster->ID = '2'; // 1101
            monster->HP = 10;
            monster->speed = 10;
            monster->attack = 5;
            monster->defense = 5;
            break;
        case(14):
            monster->ID = 'S'; // 1110 //Basilisk
            monster->HP = 10;
            monster->speed = 10;
            monster->attack = 5;
            monster->defense = 5;
            break;
        case(15):
            monster->ID = 'B'; // 1111 //Beserker - Boss lvl - High speed
            monster->HP = 50;
            monster->speed = 20;
            monster->attack = 5;
            monster->defense = 5;
            break;
    }    
}

void freeDungeon(dungeon_t *d){
    free(d->upstairs);
    free(d->downstairs);
    free(d->rooms);
    cleanCharacters(d);
}

void cleanCharacters(dungeon_t *d){
    uint8_t y, x;
    for(y = 0; y < DUNGEON_HEIGHT; y++){
        for(x = 0; x < DUNGEON_WIDTH; x++){
            if(d->characters[y][x] != NULL){
                free(d->characters[y][x]);
                d->characters[y][x] = NULL;
            }
        }
    }
}

void display(dungeon_t *d){
    uint8_t y, x;
    for (y = 0; y < DUNGEON_HEIGHT; y++){
        for (x = 0; x < DUNGEON_WIDTH; x++){
            if(d->characters[y][x] != NULL){
                printf("%c", d->characters[y][x]->ID);
            }else{
                geo_t geography;

                geography = d->map[y][x];

                switch (geography){
                case g_rock:
                    printf(" ");
                    break;
                case g_wall:
                    if (y == 0 || y == DUNGEON_HEIGHT - 1){
                        printf("-");
                    }else{
                        printf("|");
                    }
                    break;
                case g_room:
                    printf(".");
                    break;
                case g_corridor:
                    printf("#");
                    break;
                case g_up_stairs:
                    printf("<");
                    break;
                case g_down_stairs:
                    printf(">");
                    break;
                default:
                    printf("*");
                    break;
                }
            }
        }
        printf("\n");
    }
    printf("\n");
    printf("\n");
    printf("\n");
    return;
}

void displayToWin(dungeon_t *d){
    move(0,0);
    clrtoeol();
    mvprintw(0,0, "HP: %d", d->characters[d->player.y][d->player.x]->HP);
    uint8_t y, x;
    //mvprintw(0, 0, " ");
    for(y = 1; y < DUNGEON_HEIGHT + 1; y++){
        for(x = 0; x < DUNGEON_WIDTH; x++){
            if(d->characters[y-1][x] != NULL){
                mvaddch(y, x, d->characters[y-1][x]->ID);
                refresh();
            }else{
                geo_t geography;
                geography = d->map[y-1][x];
                switch (geography){
                case g_rock:
                    mvaddch(y, x, *" ");
                    refresh();
                    break;
                case g_wall:
                    if (y == 1 || y == DUNGEON_HEIGHT){
                        mvaddch(y, x, *"-");
                        refresh();
                    }else{
                        mvaddch(y, x, *"|");
                        refresh();
                    }
                    break;
                case g_room:
                    mvaddch(y, x, *".");
                    refresh();
                    break;
                case g_corridor:
                    mvaddch(y, x, *"#");
                    refresh();
                    break;
                case g_up_stairs:
                    mvaddch(y, x, *"<");
                    refresh();
                    break;
                case g_down_stairs:
                    mvaddch(y, x, *">");
                    refresh();
                    break;
                default:
                    mvaddch(y, x, *"*");
                    refresh();
                    break;
                }
            }
        }
        //refresh();
    }
    //refresh();
}

void displayPathsToWin(dungeon_t *d){
    int i, j;
    // printf("Weight graph \n");
    // for(i=0; i<DUNGEON_HEIGHT+1; i++) {
    //     for(j=0;j<DUNGEON_WIDTH+1;j++) {
    //         if(j==DUNGEON_WIDTH){
    //             printf("\n");
    //         }else if(i==DUNGEON_HEIGHT){
    //             break;
    //         }else if(d->map[i][j] == envir_x_wall || d->map[i][j] == envir_y_wall){
    //             printf("X");
    //         }else if(d->player.y == i && d->player.x == j){
    //             printf("%s", "@");
    //         }else{
    //             printf("%d", d->weight[i][j]);
    //         }
    //     }
    // }
    //printf("Non tunneling paths \n");
    for (i = 1; i < DUNGEON_HEIGHT + 1; i++){
        for (j = 0; j < DUNGEON_WIDTH; j++){
            if (d->player.y == i-1 && d->player.x == j){
                mvaddch(i, j, *"@");
            }else{
                if (d->map[i-1][j] == g_wall){
                    mvprintw(i, j, "X");
                }else if (d->nonTunnelingPaths[i-1][j] == 999 && d->hardness[i-1][j] == 0){
                    mvprintw(i, j, "X");
                }else if (d->nonTunnelingPaths[i-1][j] == 999){
                    mvprintw(i, j, " ");
                }else{
                    int display = d->nonTunnelingPaths[i-1][j] % 10;
                    mvprintw(i, j, "%d", display);
                }
            }
        }
    }
    refresh();
    // //printf("Tunneling Paths \n");
    // for (i = 0; i < DUNGEON_HEIGHT; i++){
    //     for (j = 0; j < DUNGEON_WIDTH; j++){
    //         if (d->player.y == i && d->player.x == j){
    //             mvaddch(i, j, *"@");
    //         }else{
    //             if (d->map[i][j] == g_wall){
    //                 mvaddch(i, j, *"X");
    //             }else if (d->tunnelingPaths[i][j] == 999){
    //                 mvaddch(i, j, *" ");
    //             }else{
    //                 mvaddch(i, j, *"%i", d->tunnelingPaths[i][j] % 10);
    //             }
    //         }
    //     }
    // }
    refresh();
}
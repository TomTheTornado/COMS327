#include <limits.h>
#include <stdlib.h>
#include <stdint.h>

#include "Headers/PathFinding.h"

void iniArrays(dungeon_t *d){
    uint8_t y, x;
    for (y = 0; y < DUNGEON_HEIGHT; y++){
        for (x = 0; x < DUNGEON_WIDTH; x++){
            d->nonTunnelingPaths[y][x] = 999;
            d->tunnelingPaths[y][x] = 999;
        }
    }
    return;
}

int32_t pathFinding_cmp(const void *key, const void *with){
    return ((pathFinding_t *)key)->cost - ((pathFinding_t *)with)->cost;
}

void dijkstraPF(dungeon_t *d, location_t pos, uint8_t mode){
    static pathFinding_t path[DUNGEON_HEIGHT][DUNGEON_WIDTH], *p;
    heap_t h;
    uint32_t y, x;

    heap_init(&h, pathFinding_cmp, NULL);

    for (y = 0; y < DUNGEON_HEIGHT; y++){
        for (x = 0; x < DUNGEON_WIDTH; x++){
            path[y][x].pos.y = y;
            path[y][x].pos.x = x;
            path[y][x].cost = (pos.x != x || pos.y != y) ? INT_MAX : 0;

            if (mapxy(x, y) != g_wall && mode) //fill heap if not hard wall
                path[y][x].hn = heap_insert(&h, &path[y][x]);
            else if (d->hardness[y][x] == 0) //fill heap if a room or corridor
                path[y][x].hn = heap_insert(&h, &path[y][x]);
            else
                path[y][x].hn = NULL;
        }
    }

    while ((p = heap_remove_min(&h))){
        p->hn = NULL;

        int8_t offset[3] = {-1, 0, 1};

        for (y = 0; y < 3; y++){
            for (x = 0; x < 3; x++){
                if ((path[p->pos.y + offset[y]][p->pos.x + offset[x]].hn) && (path[p->pos.y + offset[y]][p->pos.x + offset[x]].cost > p->cost + weight(p->pos.x,p->pos.y))){
                    path[p->pos.y + offset[y]][p->pos.x + offset[x]].cost = p->cost + weight(p->pos.x,p->pos.y);
                    path[p->pos.y + offset[y]][p->pos.x + offset[x]].from.y = p->pos.y;
                    path[p->pos.y + offset[y]][p->pos.x + offset[x]].from.x = p->pos.x;
                    heap_decrease_key_no_replace(&h, path[p->pos.y + offset[y]][p->pos.x + offset[x]].hn);
                }
            }
        }

        //add cost
        if (mode)
            d->tunnelingPaths[p->pos.y][p->pos.x] = p->cost;
        else
            d->nonTunnelingPaths[p->pos.y][p->pos.x] = (p->cost == INT_MAX) ? p->cost + 1 : p->cost;
    }
    heap_delete(&h);
    return;
}

void genPaths(dungeon_t *d, location_t pos){
    iniArrays(d); //init distance arrays
    dijkstraPF(d, pos, 0);    //tunneling
    dijkstraPF(d, pos, 1);    //non tunneling
}

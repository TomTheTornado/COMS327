#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <math.h>
#include <curses.h>
#include <ncurses.h>

#include "Headers/Game.h"

int comTurn(const void *key, const void *with){
    return ((turn_t *)key)->turn - ((turn_t *)with)->turn;
}

int gameLoop(dungeon_t *d){
    turn_t turn[DUNGEON_HEIGHT][DUNGEON_WIDTH], *p;
    heap_t h;
    uint32_t y, x;

    heap_init(&h, comTurn, NULL);
    //Player goes first
    turn[d->player.y][d->player.x].character = d->characters[d->player.y][d->player.x];
    turn[d->player.y][d->player.x].turn = 0;
    turn[d->player.y][d->player.x].hn = heap_insert(&h, &turn[d->player.y][d->player.x]);
    //Then the monsters
    for (y = 0; y < DUNGEON_HEIGHT; y++){
        for (x = 0; x < DUNGEON_WIDTH; x++){
            if (d->characters[y][x] != NULL && d->characters[y][x]->ID != *"@"){
                turn[y][x].character = d->characters[y][x];
                turn[y][x].turn = 0;
                turn[y][x].hn = heap_insert(&h, &turn[y][x]);
            }
        }
    }
    uint32_t previous;
    //The Game
    while ((p = heap_remove_min(&h))){
        //Check if the character is still alive to move
        if(d->characters[p->character->pos.y][p->character->pos.x] == NULL || d->characters[p->character->pos.y][p->character->pos.x]->numMonster != p->character->numMonster)
            continue;
        if(p->character->ID == *"@"){
            if(d->characters[p->character->pos.y][p->character->pos.x]->HP <= 0){
                break;
            }
            displayToWin(d);
            int next = playerMove(d, p);
            if(next == 0){
                break;
            }else if(next == 2){
                return 1;
            }else{
            displayToWin(d);
            }
        }else{
            runAI(d, p);
            //displayToWin(d);
        }
        turn_t *next = heap_remove_min(&h);
        previous = next->turn;
        heap_insert(&h, next);
        turn[p->character->pos.y][p->character->pos.x] = *p;
        turn[p->character->pos.y][p->character->pos.x].turn = previous + (1000 / p->character->speed);
        turn[p->character->pos.y][p->character->pos.x].hn = heap_insert(&h, &turn[p->character->pos.y][p->character->pos.x]);
    }
    heap_delete(&h);
    // mvprintw(0,0, "You have perished");
    // refresh();
    // getch();
    return 0;
}

#include <stdio.h>
#include <stdlib.h>
#include <curses.h>
#include <ncurses.h>
#include "Headers/Player.h"

int playerMove(dungeon_t *d, turn_t *p){
    keypad(stdscr, true);
    while(1){
        char ch = getch();
        switch(ch){
        //Movement Cases
        case('7')://Move Up-Left
        case((char)KEY_HOME):
        case('y'):
                if(d->map[p->character->pos.y - 1][p->character->pos.x - 1] == g_rock){
                    mvprintw(0,0,"There is a rock in the way!");
                    refresh();
                    continue;
                }else{
                    moveCharacterE(d, p, -1, -1);
                    displayToWin(d);
                    return 1;
                }
                break;
            
        case('8')://Move Up
        case((char)KEY_UP):
        case('k'):
            if(d->map[p->character->pos.y - 1][p->character->pos.x] == g_rock){
                mvprintw(0,0,"There is a rock in the way!");
                refresh();
                continue;
            }else{
                moveCharacterE(d, p, -1, 0);
                displayToWin(d);
                return 1;
            }
           break;
        case('9')://Move Up-Right
        case((char)KEY_PPAGE):
        case('u'):
            if(d->map[p->character->pos.y - 1][p->character->pos.x + 1] == g_rock){
                mvprintw(0,0,"There is a rock in the way!");
                refresh();
                continue;
            }else{
               moveCharacterE(d, p, -1, 1);
               displayToWin(d);
               return 1;
            }
            break;
        case('6')://Move Right
        case((char)KEY_RIGHT):
        case('l'):
            if(d->map[p->character->pos.y][p->character->pos.x + 1] == g_rock){
                mvprintw(0,0,"There is a rock in the way!");
                refresh();
                continue;
            }else{
                moveCharacterE(d, p, 0, 1);
                displayToWin(d);
                return 1;
            }
            break;
        case('3')://Move Down-Right
        case((char)KEY_NPAGE):
        case('n'):
            if(d->map[p->character->pos.y + 1][p->character->pos.x + 1] == g_rock){
                mvprintw(0,0,"There is a rock in the way!");
                refresh();
                continue;
            }else{
                moveCharacterE(d, p, 1, 1);
                displayToWin(d);
                return 1;
            }
            break;
        case('2')://Move Down
        case((char)KEY_DOWN):
        case('j'):
            if(d->map[p->character->pos.y + 1][p->character->pos.x] == g_rock){
                mvprintw(0,0,"There is a rock in the way!");
                refresh();
                continue;
            }else{
                moveCharacterE(d, p, 1, 0);
                displayToWin(d);
                return 1;
            }
            break;
        case('1')://Move Down-Left
        case('b'):
            if(d->map[p->character->pos.y + 1][p->character->pos.x - 1] == g_rock){
                mvprintw(0,0,"There is a rock in the way!");
                refresh();
                continue;
            }else{
                moveCharacterE(d, p, 1, -1);
                displayToWin(d);
                return 1;
            }
            break;
        case('4')://Move Left
        case((char)KEY_LEFT):
        case('h'):
            if(d->map[p->character->pos.y][p->character->pos.x - 1] == g_rock){
                mvprintw(0,0,"There is a rock in the way!");
                refresh();
                continue;
            // }else if(d->characters[p->pos.y][p->pos.x - 1] != NULL){
            //     battle(d, d->characters[p->pos.y][p->pos.x], d->characters[p->pos.y][p->pos.x - 1]);
            //     displayToWin(d);
            }else{
                moveCharacterE(d, p, 0, -1);
                displayToWin(d);
                return 1;
            }
            break;
        //Stair Cases -hehe
        case('>'): //Move Downstairs
            if(d->map[p->character->pos.y][p->character->pos.x] == g_down_stairs){
                //Generate a new map
                generateNextFloor(d);
                return 2;
            }else{
                mvprintw(0,0,"There is no staircase down!");
                refresh();
                continue;
            }
            //Attempt to move down a stair case
            break;
        case('<')://Move Upstairs
            if(d->map[p->character->pos.y][p->character->pos.x] == g_up_stairs){
                //Generate a new map
                generateNextFloor(d);
                return 2;
            }else{
                mvprintw(0,0,"There is no staircase up!");
                refresh();
                continue;
            }
            //Attempt to move up a stair case
            break;
        //Rest
        case((char)KEY_B2):
        case('5'):
        case(' '):
        case('.'):
            return 1;
             //Rest for a turn
            break;
        //Info
        case('m'):
            //Display list of monsters and their position
            displayMonsterList(d);
            move(0,0);
            clrtoeol();
            refresh();
            continue;
        case('Q'):
            return 0;
             //quit game
        default:
            mvprintw(0, 0, "That key doesn't do anything!");
            refresh();
            continue;
        }
    //End Switch
    }
    return 1;
}

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ncurses.h>
#include "Headers/Game.h"

int main(int argc, char const *argv[]){
    int i;

    action_t action = base;
    dungeon_t dungeon;
    dungeon.seed = 0;
    dungeon.max_monsters = MAX_MONSTERS;

    //Determine action for start of dungeon
    for(i = 1; i < argc; i++){
        if(!strcmp(argv[i], "--save") || !strcmp(argv[i], "-s"))
            action = (action != load) ? save : load_save;
        else if (!strcmp(argv[i], "--load") || !strcmp(argv[i], "-l"))
            action = (action != save) ? load : load_save;
        else if (!strcmp(argv[i], "--seed") && (i + 1 < argc))
            dungeon.seed = atoi(argv[i + 1]);
        else if (!strcmp(argv[i], "-sl") || !strcmp(argv[i], "-ls"))
            action = load_save;
        else if (!strcmp(argv[i], "--nummon") && (i + 1 < argc))
            dungeon.max_monsters = atoi(argv[i + 1]);
        else if(!strcmp(argv[i], "--7441"))
            action = testing;
    }
    //Perform Generation according to action
    switch(action){
        case(save):
            printf("saving \n");
            generate(&dungeon);
            saveDungeon(&dungeon);
            break;
        case(load):
            printf("loading \n");
            loadDungeon(&dungeon);
            //genPaths(&dungeon);
            break;
        case(load_save):
            printf("loading and saving \n");
            loadDungeon(&dungeon);
            saveDungeon(&dungeon);
            break;
        case(testing):
            generate(&dungeon);
            printf("Seed: %d\n", dungeon.seed);
            printf("Number of Monsters: %d\n", dungeon.num_monsters);
            display(&dungeon);
            break;
        default:
        initscr();
        curs_set(0);
        noecho();
        generate(&dungeon);
        while(1){
            if(!gameLoop(&dungeon)){
                break;
            }else{
                continue;
            }
        }
        // puts(
        //     "................ ...............................................................\n"
        //     "............,MMMMMMMMMM......MMMMMM......MMMM .....MMMM..MMMMMMMMMMMMM ...... ..\n"
        //     "..........,MMMM.      .....MMMM..MMMM... MMMMMM..MMMMMM. MMMM+       ...........\n"
        //     "........?MNMN:~ ........ MMMM::..::MMMM. MMMMMMMMMMMMMM. MMMM+..................\n"
        //     "........?MMMM............MMMM......MMMM. MMMMMMMMMMMMMM. MMMM+..................\n"
        //     "........?MMMM....MMMMMM..MMMM......MMMM. MMMM..MM..MMMM. MMMMMMMMMMMMM..........\n"
        //     "........?MMMM......MMMM..MMMMMMMMMMMMMM. MMMM .....MMMM. MMMM+..................\n"
        //     "..........,MNMM ...MMMM..MMMM......MMMM. MMMM .....MMMM. MMMM+..................\n"
        //     "..........:MMMM  ..MMMM..MMMM......MMMM. MMMM .....MMMM. MMMM+  ...... .........\n"
        //     "............,MMMMMMMMMM..MMMM......MMMM. MMMM .....MMMM. MMMMMMMMMMMMM..........\n"
        //     "................................... ... ........... ............................\n"
        //     "..........:OOOOOOOOOO ...OOOO......OOOO..OOOOOOOOOOOO..OOOOOOOOOOOOZ............\n"
        //     "........ .:MMMMMMMMMM.. .MMMM......MMMM. MMMMMMMMMMMM..MMMMMMMMMMMMN.. .........\n"
        //     "........?MMMM......MMMM..MMMM......MMMM. MMMM .........MMMM......?MMMM..........\n"
        //     "........?MMMM......MMMM..MMMM......MMMM. MMMM .........MMMM......IMMMM..........\n"
        //     "........?MMMM......MMMM..MMMMMM. MMMMMM. MMMMMMMMMMMM..MMMM....ZMMMMMM..........\n"
        //     "........?MMMM......MMMM. MMMMMM..MMMMMM. MMMMMMMMMMMM .MMMM....OMMMMMM .........\n"
        //     "........?MMMM......MMMM....MMMMMMMMMM... MMMM .........MMMMMMMMMM8..............\n"
        //     "........?MMMM......MMMM......MMMMMM..... MMMM .........MMMM..DMMMMMN............\n"
        //     "..........,MMMMMMMMMM..........MM....... MMMMMMMMMMMM..MMMM....ZMMMMMM..........\n"
        //     "..........,MMMMMMMMMM..........MM....... MMMMMMMMMMMM..MMMM....ZMMMMMM..........\n"
        //     "................................................................................\n"
        // );
        endwin();
        break;
    }
    freeDungeon(&dungeon);
    return 0;
}
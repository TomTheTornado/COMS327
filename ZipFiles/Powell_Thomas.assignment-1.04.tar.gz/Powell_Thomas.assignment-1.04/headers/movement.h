#ifndef movement_h
#define movement_h


void erraticPC(dungeon_t *d);

void monsterMovement(dungeon_t *d);


#endif
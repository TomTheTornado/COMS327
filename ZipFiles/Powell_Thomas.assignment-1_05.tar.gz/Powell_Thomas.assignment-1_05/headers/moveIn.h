#ifndef MOVEIN_H
# define MOVEIN_H


void nextMoveKey(int n, dungeon_t *d);

#endif